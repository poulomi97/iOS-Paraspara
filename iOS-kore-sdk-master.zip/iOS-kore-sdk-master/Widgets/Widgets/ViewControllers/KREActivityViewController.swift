//
//  KREActivityViewController.swift
//  KoreBotSDK
//
//  Created by Srinivas Vasadi on 06/03/19.
//  Copyright © 2019 Srinivas Vasadi. All rights reserved.
//

import UIKit

open class KREActivityViewController: UITableViewController {
    // MARK: - properties
    override open func viewDidLoad() {
        super.viewDidLoad()
    }
}

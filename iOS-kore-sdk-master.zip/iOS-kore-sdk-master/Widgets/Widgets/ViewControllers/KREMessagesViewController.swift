//
//  KREMessagesViewController.swift
//  KoreBotSDK
//
//  Created by Srinivas Vasadi on 07/03/19.
//  Copyright © 2019 Srinivas Vasadi. All rights reserved.
//

import UIKit

open class KREMessagesViewController: UIViewController {
    
    override open func viewDidLoad() {
        super.viewDidLoad()
    }
}

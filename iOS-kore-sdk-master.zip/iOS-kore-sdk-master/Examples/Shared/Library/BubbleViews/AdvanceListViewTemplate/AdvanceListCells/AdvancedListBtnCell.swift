//
//  AdvancedListBtnCell.swift
//  KoreBotSDKFrameWork
//
//  Created by Kartheek Pagidimarri on 28/07/23.
//  Copyright © 2023 Kartheek.Pagidimarri. All rights reserved.
//

import UIKit

class AdvancedListBtnCell: UICollectionViewCell {

    @IBOutlet weak var titleBtn: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}

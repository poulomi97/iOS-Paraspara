//
//  ButtonLinkCell.swift
//  KoreBotSDKDemo
//
//  Created by Kartheek.Pagidimarri on 06/12/21.
//  Copyright © 2021 Kore. All rights reserved.
//

import UIKit

class ButtonLinkCell: UICollectionViewCell {
    @IBOutlet weak var textlabel: UILabel!
    @IBOutlet weak var imagvWidthConstraint: NSLayoutConstraint!
    @IBOutlet var bgV: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}

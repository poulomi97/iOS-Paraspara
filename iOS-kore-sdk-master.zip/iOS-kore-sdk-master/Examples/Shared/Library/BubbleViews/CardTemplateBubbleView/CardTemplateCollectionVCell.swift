//
//  CardTemplateCollectionVCell.swift
//  KoreBotSDKFrameWork
//
//  Created by Kartheek Pagidimarri on 31/07/23.
//  Copyright © 2023 Kartheek.Pagidimarri. All rights reserved.
//

import UIKit

class CardTemplateCollectionVCell: UICollectionViewCell {
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var descLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}

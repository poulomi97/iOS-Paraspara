//
//  FeedbackCell.swift
//  KoreBotSDKDemo
//
//  Created by Kartheek Pagidimarri on 8/28/20.
//  Copyright © 2020 Kore. All rights reserved.
//

import UIKit

class FeedbackCell: UICollectionViewCell {

    @IBOutlet weak var imageView: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}

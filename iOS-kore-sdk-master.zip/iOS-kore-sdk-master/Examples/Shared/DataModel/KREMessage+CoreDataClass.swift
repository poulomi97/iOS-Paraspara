//
//  KREMessage+CoreDataClass.swift
//  KoreBotSDKDemo
//
//  Created by developer@kore.com on 21/11/16.
//  Copyright © 2016 Kore Inc. All rights reserved.
//

import Foundation
import CoreData

@objc(KREMessage)
public class KREMessage: NSManagedObject {

}

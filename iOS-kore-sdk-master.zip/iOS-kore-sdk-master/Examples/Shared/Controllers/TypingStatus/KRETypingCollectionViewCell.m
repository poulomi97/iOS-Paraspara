//
//  KRETypingCollectionViewCell.m
//  KoreApp
//
//  Created by developer@kore.com on 03/06/15.
//  Copyright (c) 2015 Kore Inc. All rights reserved.
//

#import "KRETypingCollectionViewCell.h"

@implementation KRETypingCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
- (void) prepareForReuse {
    [super prepareForReuse];
   // [self.customImageView resetProfileImage];
}
@end

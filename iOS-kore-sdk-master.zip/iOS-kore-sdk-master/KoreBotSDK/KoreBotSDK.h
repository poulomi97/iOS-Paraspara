//
//  KoreBotSDK.h
//  KoreBotSDK
//
//  Created by Srinivas Vasadi on 30/01/19.
//  Copyright © 2019 Srinivas Vasadi. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for KoreBotSDK.
FOUNDATION_EXPORT double KoreBotSDKVersionNumber;

//! Project version string for KoreBotSDK.
FOUNDATION_EXPORT const unsigned char KoreBotSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <KoreBotSDK/PublicHeader.h>


